package com.saksham.carpooling.carpoolingapis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarpoolingapisApplicationTests {

	@Test
	void contextLoads() {
	}

}
