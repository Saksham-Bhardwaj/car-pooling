package com.saksham.carpooling.carpoolingapis.model;

import javax.persistence.*;

@Entity
@Table(name="Rides")

public class Rides {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column
    private Integer rideid;
    @Column
    private String publisher;
    @Column
    private String requestors;
    @Column
    private String source;
    @Column
    private String destination;
    @Column
    private String start;
    @Column
    private Integer seats;
    @Column
    private Long contact;

    public Integer getRideid() {
        return rideid;
    }

    public void setRideid(Integer rideid) {
        this.rideid = rideid;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public String getRequestors() {
        return requestors;
    }

    public void setRequestors(String requestors) {
        this.requestors = requestors;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getStart() {
        return start;
    }

    public void setStart(String start) {
        this.start = start;
    }

    public Integer getSeats() {
        return seats;
    }

    public void setSeats(Integer seats) {
        this.seats = seats;
    }

    public Long getContact() {
        return contact;
    }

    public void setContact(Long contact) {
        this.contact = contact;
    }

    @Override
    public String toString() {
        return "Rides{" +
                "rideid=" + rideid +
                ", publisher='" + publisher + '\'' +
                ", requestors='" + requestors + '\'' +
                ", source='" + source + '\'' +
                ", destination='" + destination + '\'' +
                ", start='" + start + '\'' +
                ", seats=" + seats +
                ", contact=" + contact +
                '}';
    }
}
