package com.saksham.carpooling.carpoolingapis.service;

import com.saksham.carpooling.carpoolingapis.model.Rides;

import java.util.List;

public interface RideService {
    void addRide(Rides ride);
    List<Rides> getAllRides();
}
