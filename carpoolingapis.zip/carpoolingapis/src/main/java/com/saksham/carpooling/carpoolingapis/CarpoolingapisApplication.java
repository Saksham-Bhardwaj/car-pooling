package com.saksham.carpooling.carpoolingapis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarpoolingapisApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarpoolingapisApplication.class, args);
	}

}
