package com.saksham.carpooling.carpoolingapis.controller;

import com.saksham.carpooling.carpoolingapis.model.CarDetails;
import com.saksham.carpooling.carpoolingapis.model.Rides;
import com.saksham.carpooling.carpoolingapis.model.User;
import com.saksham.carpooling.carpoolingapis.service.CarService;
import com.saksham.carpooling.carpoolingapis.service.RideService;
import com.saksham.carpooling.carpoolingapis.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class UserController {
    @Autowired
    private UserService userService;

    @Autowired
    private CarService carService;
    @Autowired
    private RideService rideService;

    @GetMapping("/user")
    public List<User> getUsers(){
        return userService.getAllUsers();
    }
    @GetMapping("/user/contact")
    public User getUserByContact(@RequestParam Long contact){
        System.out.println(contact);
        return userService.getUserByContact(contact);
    }

    @PostMapping("/adduser")
    public User addUser(@RequestBody User userObj){
        userService.addUser(userObj);
        return userObj;
    }

    @GetMapping("/car")
    public List<CarDetails> getCars(){
        return carService.getAllCars();
    }

    @PostMapping("/addcar")
    public CarDetails addCar(@RequestBody CarDetails carObj){
        carService.addCar(carObj);
        return carObj;
    }

    @GetMapping("/ride")
    public List<Rides> getRides(){
        return rideService.getAllRides();
    }

    @PostMapping("/addride")
    public Rides addRide(@RequestBody Rides rideObj){
        rideService.addRide(rideObj);
        return rideObj;
    }
}
