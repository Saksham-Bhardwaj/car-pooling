package com.saksham.carpooling.carpoolingapis.dao;


import com.saksham.carpooling.carpoolingapis.model.CarDetails;
import com.saksham.carpooling.carpoolingapis.model.Rides;
import com.saksham.carpooling.carpoolingapis.model.User;
import java.util.List;

public interface UserDao {
    void addUser(User u);
    void addCar(CarDetails car);
    void addRide(Rides ride);
    List<Rides> getAllRides();
    User getUserByContact(Long contact);
    List<User> getAllUsers();
    List<CarDetails> getAllCars();
}
