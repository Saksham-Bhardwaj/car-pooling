package com.saksham.carpooling.carpoolingapis.service;

import com.saksham.carpooling.carpoolingapis.dao.UserDao;
import com.saksham.carpooling.carpoolingapis.model.CarDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class CarServiceImpl implements CarService {
    @Autowired
    private UserDao userDao;

    @Transactional
    @Override
    public void addCar(CarDetails car) {
        userDao.addCar(car);
    }

    @Transactional
    @Override
    public List<CarDetails> getAllCars() {
        return userDao.getAllCars();
    }
}
