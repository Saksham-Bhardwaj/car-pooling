package com.saksham.carpooling.carpoolingapis.service;

import com.saksham.carpooling.carpoolingapis.model.User;
import java.util.List;

public interface UserService {
    void addUser(User u);
    User getUserByContact(Long contact);
    List<User> getAllUsers();
}
