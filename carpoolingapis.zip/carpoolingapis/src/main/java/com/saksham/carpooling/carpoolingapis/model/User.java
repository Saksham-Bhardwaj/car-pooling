package com.saksham.carpooling.carpoolingapis.model;
import javax.persistence.*;

@Entity
@Table(name="Users")

public class User {
    @Id
    //@GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column
    private String name;
    @Column
    private String email;
    @Column
    private String drivinglicense;
    @Column
    private Long contact;
    @Column
    private String cardetails;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDrivinglicense() {
        return drivinglicense;
    }

    public void setDrivinglicense(String drivinglicense) {
        this.drivinglicense = drivinglicense;
    }

    public Long getContact() {
        return contact;
    }

    public void setContact(Long contact) {
        this.contact = contact;
    }

    public String getCardetails() {
        return cardetails;
    }

    public void setCardetails(String cardetails) {
        this.cardetails = cardetails;
    }

    @Override
    public String toString() {
        return "User{" +
                "name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", drivinglicense='" + drivinglicense + '\'' +
                ", contact=" + contact +
                ", cardetails='" + cardetails + '\'' +
                '}';
    }
}
