package com.saksham.carpooling.carpoolingapis.dao;
import com.saksham.carpooling.carpoolingapis.model.CarDetails;
import com.saksham.carpooling.carpoolingapis.model.Rides;
import com.saksham.carpooling.carpoolingapis.model.User;
import com.saksham.carpooling.carpoolingapis.model.Validator;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.util.List;

@Repository
public class UserDaoImpl implements UserDao {
    @Autowired
    private EntityManager entityManager;
    @Autowired
    private Validator validator;
    @Override
    public void addUser(User user) {
        Session currentSession = entityManager.unwrap(Session.class);
        if(validator.userValidator(user)) {
            currentSession.save(user);
        }
    }

    //@Override
    public User getUserByContact(Long contact) {
        Session currentSession = this.entityManager.unwrap(Session.class);
        Query query = currentSession.createQuery("from User u where u.contact = :contact",User.class).setParameter("contact",contact);
        List<User> list = query.getResultList();
        return list.get(0);
    }


    @Override
    public void addCar(CarDetails car) {
        Session currentSession = this.entityManager.unwrap(Session.class);
        if(!validator.carValidator(car)){
            return;
        }
        User userObj = this.getUserByContact(car.getContact());
        System.out.println(userObj);
        if(userObj!=null){
            currentSession.save(car);
            userObj.setCardetails(car.getCarid());
            currentSession.update(userObj);
        }

    }

    @Override
    public void addRide(Rides ride) {
        Session currentSession = entityManager.unwrap(Session.class);
        if(validator.rideValidator(ride)){
            currentSession.save(ride);
        }

    }

    @Override
    public List<Rides> getAllRides() {
        Session currentSession = this.entityManager.unwrap(Session.class);
        Query query =currentSession.createQuery("from Rides",Rides.class);
        List<Rides> list =query.getResultList();
        return list;
    }

    @Override
    public List<User> getAllUsers() {
        Session currentSession = this.entityManager.unwrap(Session.class);
        Query query =currentSession.createQuery("from User",User.class);
        List<User> list =query.getResultList();
        return list;
    }

    @Override
    public List<CarDetails> getAllCars() {
        Session currentSession = this.entityManager.unwrap(Session.class);
        Query query =currentSession.createQuery("from CarDetails",CarDetails.class);
        List<CarDetails> list =query.getResultList();
        return list;
    }
}
