package com.saksham.carpooling.carpoolingapis.model;

import org.springframework.stereotype.Service;

@Service
public class Validator {

    public boolean rideValidator(Rides ride){
        if(!ride.getPublisher().matches("^[a-zA-Z]{1,}$") || !ride.getContact().toString().matches("^[6-9][0-9]{9}$") || !ride.getDestination().matches("^[a-zA-Z]{1,}$") || !ride.getSource().matches("^[a-zA-Z]{1,}$") || ride.getSeats()<1){
            return false;
        }
        return true;
    }

    public boolean userValidator(User user){
        if((user.getContact().toString()).matches("^[6-9][0-9]{9}$") && user.getEmail().matches("^[a-zA-Z]{1,}[a-zA-Z0-9_.]{1,}[@][a-zA-Z.]{1,}[.com]$") && user.getName().matches("^[a-zA-Z]{1,}$")) {
            return true;
        }
        return false;
    }

    public boolean carValidator(CarDetails car){
        if(car.getCarid().length()<9 || !car.getContact().toString().matches("^[6-9][0-9]{9}$") || car.getCompany().length()<1 || car.getSeats()<1){
            return false;
        }
        return true;
    }

}
