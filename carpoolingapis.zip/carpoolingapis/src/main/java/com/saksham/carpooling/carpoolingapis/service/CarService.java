package com.saksham.carpooling.carpoolingapis.service;

import com.saksham.carpooling.carpoolingapis.model.CarDetails;

import java.util.List;

public interface CarService {
    void addCar(CarDetails car);
    List<CarDetails> getAllCars();
}
