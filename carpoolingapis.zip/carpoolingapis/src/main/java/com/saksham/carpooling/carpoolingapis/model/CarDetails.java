package com.saksham.carpooling.carpoolingapis.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Cardetails")
public class CarDetails {
    @Id
    //
    @Column
    private String carid;
    @Column
    private String carmodel;
    @Column
    private Integer seats;
    @Column
    private String company;
    @Column
    private String ownername;
    @Column
    private Long contact;

    public String getCarid() {
        return carid;
    }

    public void setCarid(String carid) {
        this.carid = carid;
    }

    public String getCarmodel() {
        return carmodel;
    }

    public void setCarmodel(String carmodel) {
        this.carmodel = carmodel;
    }

    public Integer getSeats() {
        return seats;
    }

    public void setSeats(Integer seats) {
        this.seats = seats;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getOwnername() {
        return ownername;
    }

    public void setOwnername(String ownername) {
        this.ownername = ownername;
    }

    public Long getContact() {
        return contact;
    }

    public void setContact(Long contact) {
        this.contact = contact;
    }

    @Override
    public String toString() {
        return "CarDetails{" +
                "carid='" + carid + '\'' +
                ", carmodel='" + carmodel + '\'' +
                ", seats=" + seats +
                ", company='" + company + '\'' +
                ", ownername='" + ownername + '\'' +
                ", contact=" + contact +
                '}';
    }
}
